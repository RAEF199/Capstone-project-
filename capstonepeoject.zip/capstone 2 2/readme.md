Capstone project 
This is the final project in front-end web developer with Udacity.

The idea of this project is to provide weather information with beatiful picture for a specific city enered by the user.
the weather info depend on the departing date  which is also enered by the user, if it more than 7 days the app will provide current weather information else the app will provide future weather information.

-Three APIs used in this project
1- Geonames to get longitude and latitude for apecific city
2- Weatherbit to get forcast and current weather information 
3- Pixabay to provide beatifu picture for the city 

-Save button used for displaying the information 
-Remove button used for deleting all thee information and start again 

steps to run the application in the browser:
1- enter the city you want to trvel to 
2- enter the departing date
3- enter the return date
4- finally press the save button to display information
5- to remove trip and start again click remove 

steps to run the application as a developer:
1- in terminal install npm through this command (npm install)
2- then npm run build-dev 
3- npm run build-prod
4- finally npm start 

I made 2 of (Suggestions to Make Your Project Stand Out)
1- Add end date and display length of trip
2- Allow the user to remove the trip



